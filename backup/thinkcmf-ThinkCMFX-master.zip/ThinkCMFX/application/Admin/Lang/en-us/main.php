<?php
return array(
	'SYSTEM_INFORMATIONS' => 'System Informations',
	'SYSTEM_NOTIFICATIONS' => 'System Notifications',
	'INITIATE_TEAM' => 'Initiate Team',
	'CONTRIBUTORS' => 'Contributors',
	'CONTACT_EMAIL' => 'Contact Email',
	'TEAM_MEMBERS' => 'Team Members',
	'OPERATING_SYSTEM' => 'OS',
	'OPERATING_ENVIRONMENT' =>'Server Software',
    'PHP_VERSION' => 'PHP Version',
	'PHP_RUN_MODE' => 'PHP Run Mode',
	'MYSQL_VERSION' => 'MySQL Version',
	'PROGRAM_VERSION' => 'Program Version',
	'UPLOAD_MAX_FILESIZE' => 'Upload Limit',
	'MAX_EXECUTION_TIME' =>'Execution Limit',
	'DISK_FREE_SPACE' => 'Disk Free Space',
	'SECONDS' => 's',
	'UNKNOWN' => 'Unknown',
	'NO_NOTICE' => 'No notice'
		

);