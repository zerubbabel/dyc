<?php
return array(
    "NAME" => "Name",
    "CATEGORY_KEY" => 'Category Key',
    "DESCRIPTION" => "Description",
    "DEFAULT_CATEGORY" => "Default Category",
    "NOT_ALLOWED_EDIT" => "Not Allowed to edit",
    "CATEGORY_KEY_HELP_TEXT" => 'ALPHANUM or Underscores'
);