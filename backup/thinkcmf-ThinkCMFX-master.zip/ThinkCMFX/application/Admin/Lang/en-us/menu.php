<?php
return array(
		"APP" => 'App',
		"NAME" => 'Name',
		"ADD_SUB_MENU" => 'Add Sub Menu'
);